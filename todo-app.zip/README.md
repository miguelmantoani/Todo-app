# Sistema de Tarefas (To-Do App)

Este é um projeto simples de aplicação web full stack para gerenciamento de tarefas, desenvolvido com HTML, CSS, JavaScript puro no front-end e Node.js com Express no back-end.

## Funcionalidades

- Adicionar nova tarefa
- Listar tarefas cadastradas
- Excluir tarefas

## Tecnologias utilizadas

### Front-end
- HTML5
- CSS3
- JavaScript (Fetch API)

### Back-end
- Node.js
- Express
- SQLite

## Como executar o projeto

### Requisitos
- Node.js instalado
- npm (gerenciador de pacotes do Node)

### Passos

1. Navegue até a pasta `backend` e execute:
```
npm install express sqlite3 cors
node server.js
```

2. Em outro terminal, abra o `index.html` na pasta `frontend` com um navegador web.

A aplicação estará disponível e conectada ao back-end local rodando em `http://localhost:3000`.

## Licença
Este projeto é de uso livre para fins educacionais.
