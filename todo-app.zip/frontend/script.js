const taskForm = document.getElementById("task-form");
const taskInput = document.getElementById("task-input");
const taskList = document.getElementById("task-list");

async function loadTasks() {
  const res = await fetch("http://localhost:3000/tasks");
  const tasks = await res.json();
  taskList.innerHTML = "";
  tasks.forEach((task) => {
    const li = document.createElement("li");
    li.className = "task-item";
    li.innerHTML = `
      ${task.title}
      <button onclick="deleteTask(${task.id})">Excluir</button>
    `;
    taskList.appendChild(li);
  });
}

taskForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const title = taskInput.value;
  await fetch("http://localhost:3000/tasks", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title }),
  });
  taskInput.value = "";
  loadTasks();
});

async function deleteTask(id) {
  await fetch("http://localhost:3000/tasks/" + id, { method: "DELETE" });
  loadTasks();
}

loadTasks();